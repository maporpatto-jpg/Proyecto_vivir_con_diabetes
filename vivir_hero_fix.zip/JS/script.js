// === Escalado de imagen del HERO cuando el navegador usa "zoom solo texto" ===
// Mide 1rem en píxeles y aplica ese mismo factor a .hero-bg via transform: scale().
(function(){
  const BASE_REM_PX = 16;
  let lastScale = 1;

  function measureRemPx(){
    const probe = document.createElement('div');
    probe.style.position = 'absolute';
    probe.style.visibility = 'hidden';
    probe.style.height = '1rem';
    probe.style.width = '1rem';
    probe.style.pointerEvents = 'none';
    document.documentElement.appendChild(probe);
    const px = probe.getBoundingClientRect().height || BASE_REM_PX;
    probe.remove();
    return px;
  }

  function applyScale(){
    const remPx = measureRemPx();
    let scale = remPx / BASE_REM_PX;
    if (scale < 1) scale = 1; // evita bandas al reducir
    if (Math.abs(scale - lastScale) > 0.01) {
      document.querySelectorAll('.hero-bg').forEach(img => {
        img.style.transform = `scale(${scale})`;
        img.style.transformOrigin = 'center center';
        img.style.willChange = 'transform';
      });
      lastScale = scale;
    }
  }

  window.addEventListener('DOMContentLoaded', applyScale);
  window.addEventListener('load', applyScale);
  window.addEventListener('resize', applyScale);
  try{ new ResizeObserver(applyScale).observe(document.documentElement); }catch(e){}
  let tries = 20; const i = setInterval(()=>{applyScale(); if(--tries<=0) clearInterval(i);}, 200);
})();
